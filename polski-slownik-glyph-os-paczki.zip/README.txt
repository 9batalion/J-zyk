POLSKI SŁOWNIK — PACZKI DLA GLYPH OS
======================================

Gotowe pliki TXT do importu partiami. Każdy wiersz zawiera jedno hasło.
Kodowanie: UTF-8. Normalizacja: NFC. Wielkość liter nie tworzy duplikatów.

SZYBKI START
------------
1. Rozpakuj archiwum ZIP.
2. W aplikacji otwórz import słownika.
3. Importuj po kolei pliki z katalogu „01-podstawowy-150000”.
4. Każdy z 10 plików zawiera dokładnie 15 000 haseł.
5. Jeśli chcesz pełniejszy zasób, potem importuj pliki z katalogu
   „02-rozszerzenie-do-pelnego”.

ZAWARTOŚĆ
---------
- zbiór podstawowy: 150 000 haseł,
- rozszerzenie: 193 070 haseł,
- łącznie: 343 070 unikatowych haseł,
- rozmiar pojedynczej paczki: maksymalnie 15 000 haseł.

KOLEJNOŚĆ
---------
Hasła obecne w polskim korpusie FrequencyWords/OpenSubtitles 2018 są na
początku według częstości. Pozostałe hasła są uporządkowane najpierw według
długości, a następnie alfabetycznie. Dzięki temu pierwsze paczki są najbardziej
użyteczne w codziennym tekście.

ŹRÓDŁA I LICENCJE
-----------------
1. Polski słownik LibreOffice / SJP.PL:
   https://github.com/LibreOffice/dictionaries/tree/master/pl_PL
   commit: 32b006a2c22a4ac7e8ed3f03346f7b3d85a970a4
   wersja źródła: 2026-05-11
   Informacje o licencjach są w katalogu LICENSES. Do przygotowania tej paczki
   przyjęto dostępne w źródle licencje Apache 2.0 / CC BY 4.0.

2. FrequencyWords, polska lista OpenSubtitles 2018:
   https://github.com/hermitdave/FrequencyWords/tree/master/content/2018/pl
   commit: 525f9b560de45753a5ea01069454e72e9aa541c6
   Dane: CC BY-SA 4.0. Kod projektu: MIT.

Dobór i kolejność haseł w tej paczce korzystają z FrequencyWords, dlatego przy
dalszej redystrybucji zachowaj atrybucję i warunki CC BY-SA 4.0:
https://creativecommons.org/licenses/by-sa/4.0/

KONTROLA INTEGRALNOŚCI
----------------------
Plik manifest.json zawiera liczbę haseł i sumę SHA-256 każdego pliku TXT.
